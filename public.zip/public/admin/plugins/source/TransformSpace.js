const TransformSpace =
{
	Local:0,
	World:1
};

export default TransformSpace;
