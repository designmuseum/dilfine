export default class AnimatedComponent
{
	constructor(componentIndex)
	{
		this._ComponentIndex = componentIndex;
		this._Properties = [];
	}
}